
import torch

def Scheduler_Establishment(optimizer, args):
    #model = globals()[model_name.capitalize()]()

    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=0.)

    return scheduler
