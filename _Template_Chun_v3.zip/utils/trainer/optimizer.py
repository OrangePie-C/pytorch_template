
import torch.optim as optim







def Optimizer_Establishment(model, args):
    #model = globals()[model_name.capitalize()]()
    #optimizer = getattr(optim, args.optimizer)()
    #optimizer = optim.SGD(model.parameters(), args.lr)
    optimizer = getattr(optim, args.optimizer)(model.parameters(), args.lr, momentum=args.momentum, weight_decay=args.decay)

    return optimizer