import pdb

import torch
import torch.nn as nn

import torch.nn.functional as F
from torch.autograd import Variable


class SiLogLoss(nn.Module):
    def __init__(self, lambd=0.5):
        super().__init__()
        self.lambd = lambd

    def forward(self, pred, target):
        valid_mask = (target > 0).detach()
        diff_log = torch.log(target[valid_mask]) - torch.log(pred[valid_mask])
        loss = torch.sqrt(torch.pow(diff_log, 2).mean() - self.lambd * torch.pow(diff_log.mean(), 2))

        return loss





class CrossEntropyLoss(nn.Module):
    def __init__(self, ignore_index=255):
        super().__init__()
        self.criterion = nn.CrossEntropyLoss(ignore_index=ignore_index)

    def forward(self, pred, target):
        loss = self.criterion(pred, target)

        return loss


class L1Loss(nn.Module):
    def __init__(self):
        super().__init__()
        self.criterion = nn.L1Loss()

    def forward(self, pred, target):
        target = target.float()
        loss = self.criterion(pred, target) * 0.1
        return loss

class MSELoss(nn.Module):
    def __init__(self):
        super().__init__()
        self.criterion = nn.MSELoss()

    def forward(self, pred, target):
        target = target.float()
        loss = self.criterion(pred, target)
        return loss


def criterion_establishment(args) -> object:
    criterion_dict = {}
    criterion_dict['loss_name_1'] = CrossEntropyLoss()  # variable()
    criterion_dict['loss_name_2'] = MSELoss()  # variable()
    return criterion_dict


