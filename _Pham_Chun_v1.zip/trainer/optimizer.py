
import torch.optim as optim







def Optimizer_Establishment(model, args):
    #model = globals()[model_name.capitalize()]()
    #optimizer = optim.SGD(model.parameters(), args.lr)
    #optimizer = optim.SGD(model.parameters(), lr=args.lr, momentum=args.momentum, weight_decay=args.decay )
    optimizer = getattr(optim, args.optimizer)(model.parameters(), lr=args.lr, weight_decay=args.decay)  # 1 should change
    return optimizer