
import torch

def Scheduler_Establishment(optimizer, args):
    #model = globals()[model_name.capitalize()]()

    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=0.)
    # scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[2,4,7,11,16,116,200,250], gamma=0.5)
    return scheduler
