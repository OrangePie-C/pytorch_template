import argparse
import yaml


# config_dict = yaml.load(f, Loader=yaml.FullLoader)


def Load_Config():
    parser = argparse.ArgumentParser(description='Process some integers.')
    parser.add_argument('-c', '--config', type=str, default='./config/configuration.yaml')
    parser_sub = parser.parse_args()

    with open(parser_sub.config) as f:
        config_dict = yaml.load(f, Loader=yaml.FullLoader)

    for i in config_dict:
        if isinstance(config_dict[i], int):
            config_type = int
        elif isinstance(config_dict[i], float):
            config_type = float
        elif isinstance(config_dict[i], str):
            config_type = str
        elif isinstance(config_dict[i], list):
            config_type = list
        elif isinstance(config_dict[i], dict):
            config_type = dict
        else:
            exit("Error on the configuration")
        parser.add_argument('-' + i, type=config_type, default=config_dict[i])

    return parser


def Train_Config():
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    # base configs
    parser.add_argument('--gpu_or_cpu', type=str, default='gpu')
    parser.add_argument('--data_path', type=str, default='/mnt/ssd1/')
    parser.add_argument('--dataset', type=str, default='cityscapes',
                        choices=['cityscapes', 'nyudepthv2', 'kitti', 'ImagePath'])

    return parser


def Test_Config():
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    # base configs
    parser.add_argument('--gpu_or_cpu', type=str, default='gpu')
    parser.add_argument('--data_path', type=str, default='/mnt/ssd1/')
    parser.add_argument('--dataset', type=str, default='cityscapes',
                        choices=['cityscapes', 'nyudepthv2', 'kitti', 'ImagePath'])

    return parser
