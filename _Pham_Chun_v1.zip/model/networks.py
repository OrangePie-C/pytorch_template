import model
import torch
import torch.backends.cudnn as cudnn

import torch.nn as nn
import torch.nn.functional as F
from base import BaseModel
import torch.autograd as autograd

config = [
    [],
    # encoder type 1
    [
        [(5, 1), 32, (2, 1), (2, 0)], # kernel size, input channel, output num, padding
        [(3, 1), 64, (2, 1), (1, 0)],
        [(3, 1), 128, (2, 1), (1, 0)],
        [(3, 1), 256, (2, 1), (1, 0)],
        [(3, 1), 512, (2, 1), (1, 0)],

        [(1, 3), 512, (1, 2), (0, 1)],
        [(1, 3), 512, (1, 2), (0, 1)],
        [(1, 3), 512, (1, 2), (0, 1)]
    ],
    # encoder type 2
    [
        [(5, 1), 64, (2, 1), (2, 0)],
        [(3, 1), 128, (2, 1), (1, 0)],
        [(3, 1), 256, (2, 1), (1, 0)],
        [(3, 1), 512, (2, 1), (1, 0)],
        [(3, 1), 1024, (2, 1), (1, 0)],

        [(1, 3), 1024, (1, 2), (0, 1)],
        [(1, 3), 1024, (1, 2), (0, 1)],
        [(1, 3), 1024, (1, 2), (0, 1)]
    ]
]


# def RESTNET30():

class conv_bn_lrelu(nn.Module):
    def __init__(self, filter_shape, input_shape, num_filters, strides, padding = (1, 0), name = None):
        super().__init__()
        self.conv = nn.Conv2d(input_shape, num_filters, kernel_size=filter_shape, stride=strides, padding=padding) # may need padding
        self.bn = nn.BatchNorm2d(num_filters, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True,
                                 device=None, dtype=None)
        self.lrelu = nn.LeakyReLU(negative_slope=0.01, inplace=False)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.lrelu(x)
        return x


class PhamNet_encoder(BaseModel):
    def __init__(self, data_shape, encoder_type=1):
        super().__init__()
        self.config = config[encoder_type]
        # if data_shape != 1:
        #     exit("datashape")
        self.conv_bn_lrelu_1 = conv_bn_lrelu(filter_shape=self.config[0][0], input_shape=data_shape,
                                             num_filters=self.config[0][1],
                                             strides=self.config[0][2], padding=self.config[0][3], name="conv1")
        self.conv_bn_lrelu_2 = conv_bn_lrelu(filter_shape=self.config[1][0], input_shape=self.config[0][1],
                                             num_filters=self.config[1][1],
                                             strides=self.config[1][2], padding=self.config[1][3], name="conv2")

        self.conv_bn_lrelu_3 = conv_bn_lrelu(filter_shape=self.config[2][0], input_shape=self.config[1][1],
                                             num_filters=self.config[2][1],
                                             strides=self.config[2][2], padding=self.config[2][3],name="conv3")

        self.conv_bn_lrelu_4 = conv_bn_lrelu(filter_shape=self.config[3][0], input_shape=self.config[2][1],
                                             num_filters=self.config[3][1],
                                             strides=self.config[3][2], padding=self.config[3][3], name="conv4")

        self.conv_bn_lrelu_5 = conv_bn_lrelu(filter_shape=self.config[4][0], input_shape=self.config[3][1],
                                             num_filters=self.config[4][1],
                                             strides=self.config[4][2], padding=self.config[4][3], name="conv5")

        self.conv_bn_lrelu_t1 = conv_bn_lrelu(filter_shape=self.config[5][0], input_shape=self.config[4][1],
                                              num_filters=self.config[5][1],
                                              strides=self.config[5][2], padding=self.config[5][3], name="conv6")

        self.conv_bn_lrelu_t2 = conv_bn_lrelu(filter_shape=self.config[6][0], input_shape=self.config[5][1],
                                              num_filters=self.config[6][1],
                                              strides=self.config[6][2], padding=self.config[6][3], name="conv7")

        self.conv_bn_lrelu_t3 = conv_bn_lrelu(filter_shape=self.config[7][0], input_shape=self.config[6][1],
                                              num_filters=self.config[7][1],
                                              strides=self.config[7][2], padding=self.config[7][3], name="conv8")

    def forward(self, x):

        x = self.conv_bn_lrelu_1(x)
        x = self.conv_bn_lrelu_2(x)
        x = self.conv_bn_lrelu_3(x)
        x = self.conv_bn_lrelu_4(x)
        x = self.conv_bn_lrelu_5(x)

        x = self.conv_bn_lrelu_t1(x)
        x = self.conv_bn_lrelu_t2(x)
        x = self.conv_bn_lrelu_t3(x)

        return x


class PhamNet_decoder(BaseModel):

    def __init__(self, model_type='lstm', num_blendshape=46, input_shape=None):
        super().__init__()
        self.hidden_dim = 256 # tunable?

        self.model_type = model_type
        if self.model_type == 'cnn':
            self.dimdim = 1024
            self.module_1 = nn.Linear(input_shape, 1024)
            # tanh
        elif self.model_type == 'gru':
            self.module_1 = nn.GRU(input_shape, self.dimdim, 1)  # number of layer is unknwon????
        elif self.model_type == 'lstm':
            #print(input_shape)
            self.module_1 = nn.LSTM(input_size = input_shape, hidden_size = self.hidden_dim, dropout = 0.0, batch_first = True)
            # (batch, seq, feature)
            # or (seq, batch, feature)

            #self.module_1 = nn.Linear(input_shape, self.dimdim)
        # elif self.model_type == 'bigru':
        #     #self.module_1 =
        # elif self.model_type == 'bilstm':
        #     #self.module_1 =

        self.fc1 = nn.Linear(self.hidden_dim, num_blendshape)

    # def init_state(self, sequence_length):
    #     return (torch.zeros(256, sequence_length, self.lstm_size),
    #             torch.zeros(256, sequence_length, self.lstm_size))

    def init_hidden(self, seq_length):
        return (autograd.Variable(torch.randn(1, seq_length, self.hidden_dim).cuda()),
                autograd.Variable(torch.randn(1, seq_length, self.hidden_dim).cuda()))

    def forward(self, x):

        hidden_and_cell = self.init_hidden(x.shape[0]) # ????????????????
        x, _ = self.module_1(x, hidden_and_cell)
        if self.model_type == 'cnn':
            x = F.tanh(x)
        x = F.dropout(x, p=0.2)
        x = self.fc1(x)

        return x


class PhamNet_Integrated(BaseModel):
    def __init__(self, encoder_type=1, model_type='lstm', num_blendshape=46, data_shape=None):
        super().__init__()
        self.encoder = PhamNet_encoder(data_shape, encoder_type)
        self.decoder = PhamNet_decoder(model_type, num_blendshape, 16 * 512)

    def forward(self, x):

        x = self.encoder(x)
#        x = torch.flatten(x)
        x = x.reshape([1, -1, 8192]) # not sure

        x = self.decoder(x)
        return x




def Model_Establishment(args):
    net = getattr(model, args.model_name)(int(args.encoder_type), args.model_type, 46, 1) # 1 should change

    if args.device == 'gpu':
        device = torch.device('cuda')
        cudnn.benchmark = True
        net = torch.nn.DataParallel(net)
    else:
        device = torch.device('cpu')

    net.to(device)

    return net
