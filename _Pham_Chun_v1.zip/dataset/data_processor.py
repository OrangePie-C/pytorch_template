import torch
from torchvision import datasets, transforms
from torchvision.datasets import ImageFolder
from base import BaseDataLoader
from torch.utils.data import Dataset
import numpy as np
import os
from utils import extract_spectrogram


class RAVDESS(ImageFolder):



    def __init__(self, root, train = True, transform=None):

        #super(RAVDESS, self).__init__(root)
        #super().__init__()
        self.root = root
        self.train = train  # training set or test set
        self.input_folders = os.listdir(self.root + '/audio')
        self.gt_folders = os.listdir(self.root + '/exp')

        self.spliter = 0.8
        # if self.train:
        #     downloaded_list = self.train_list
        # else:
        #     downloaded_list = self.test_list


        # only apply speech... not song

        self.data = []
        self.targets = []
        filelist = []
        # for train and validation,,, split them??? maybe?

        # now load the picked numpy arrays
        # data
        for i in self.gt_folders:
            #files = [f for f in self.gt_folders if os.path.isfile(f)]
            filename_list = os.listdir(self.root + '/exp/' + i)
            for j in filename_list:
                filelist.append(j[2:-4])
                self.targets.append(np.load(self.root+'/exp/' + i + '/' + j))

        for i in self.input_folders:
            filename_list = os.listdir(self.root + '/audio/' + i)
            for j in filename_list:
                if j[2:-4] not in filelist:
                    continue
                self.data.append(self.root + '/audio/' + i + '/' + j)

        if train:
            self.data = self.data[:int(len(self.data)*self.spliter)]
            self.targets = self.targets[:int(len(self.targets) * self.spliter)]

        else:
            self.data = self.data[int(len(self.data) * self.spliter):]
            self.targets = self.targets[int(len(self.targets) * self.spliter):]



    def __getitem__(self, index):
        dir, target = self.data[index], self.targets[index]
        # 여기서 data에서 spectrum 뽑아야함.

        spectrogram = extract_spectrogram.extract_one_file(dir)
        spectrogram = torch.tensor(spectrogram)
        target = torch.tensor(target)

        return spectrogram, target

    def __len__(self) -> int:
        return len(self.data)





def load_dataset(args,train=True):

    # Set Transformations (variable)
    transform_train = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),

    ])

    # Load dataset (variable)
    if args.data['dataset'] == 'MNIST':
        trainset = datasets.MNIST(root=args.directory['data_dir'], train=train, download=True, transform=transform_train)
    elif args.data['dataset'].lower() == 'ravdess':
        trainset = RAVDESS(root=args.directory['data_dir'], train=train, transform=transform_train)

    else:
        raise ValueError(args.data['dataset'])


    return trainset
