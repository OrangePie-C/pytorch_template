import pdb
import os
import cv2
import time
import numpy as np
from datetime import datetime
# from model_chun import DDRNet_23_slim_Chun
import torch

import torch.optim as optim
import torch.backends.cudnn as cudnn
# from tensorboardX import SummaryWriter
# from tensorboardX.utils import make_grid
from torch.nn.parallel import DistributedDataParallel as DDP

# import models
# import tools.utils as utils
# import tools.logging as logging
# import tools.metrics as metrics
# import tools.criterion as criterion
# from tools.logging import AverageMeter, progress_bar

# from dataset.base_dataset import get_dataset

from torch.utils.data import DataLoader
# custom
from config import config  # , configuration
from dataset import data_loaders
from torch.utils.tensorboard import SummaryWriter
from commons.logger import get_logger, add_filehandler
from commons.visualization import TensorboardWriter
from dataset.data_processor import load_dataset

from model.networks import Model_Establishment

from trainer import metric
from trainer import criterion
from trainer.criterion import criterion_establishment  # loss related
from trainer.metric import MetricTracker
from trainer.optimizer import Optimizer_Establishment  # optimizer related
from trainer.scheduler import Scheduler_Establishment

from utils.util import Initialization, Finalization
from functions.operator import train_epoch, validate_epoch
from itertools import chain

import sys
import warnings

if not sys.warnoptions:
    warnings.simplefilter("ignore")


def main():
    # save model + resume?

    # Initialization : Configuration, Logger,
    args = config.Load_Config().parse_args()
    logger, TBwriter, path = Initialization(args)

    results_dict = {
        '1_loss_list': args.metrics['1_loss_list'],  # regarding
        '2_metric_list': args.metrics['2_metric_list'],
        '3_etc_list': args.metrics['3_etc_list']
                    }

    result_list = list(chain.from_iterable(list(results_dict.values())))


    # Dataloader
    train_dataset = load_dataset(args, train=True)
    val_dataset = load_dataset(args, train=False)

    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch, shuffle=True,
                                               num_workers=args.workers, pin_memory=True)
    val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=args.batch, shuffle=False,
                                             num_workers=args.workers, pin_memory=True)
    data_shape = (1, 128, 32)

    # Model
    model = Model_Establishment(args)

    # Trainer Option
    loss_functions = [getattr(criterion, loss) for loss in results_dict['1_loss_list']]
    metric_functions = [getattr(metric, met) for met in results_dict['2_metric_list']]
    optimizer = Optimizer_Establishment(model, args)
    scheduler = Scheduler_Establishment(optimizer, args)
    meter_train = MetricTracker(result_list, results_dict, writer=TBwriter['train'])
    meter_val = MetricTracker(result_list, results_dict, writer=TBwriter['val'])



    # Finalization
    model, optimizer, loss_functions, starting_epoch, best_perf, scaler, args, path = Finalization(model, optimizer,loss_functions, path, logger, args, data_shape)

    #model, optimizer, starting_epoch, best_perf, args = Finalization(model, optimizer, model_path, logger, args)

    # Write Network
    meter_train.write_network(model, args)
    meter_val.write_network(model, args)

    logger.info("Start Training...\n")


    start_time = time.time()

    for epoch in range(starting_epoch, args.epochs + 1):

        if epoch > 1 :
            print("\nAn epoch Time: " + str((time.time() - start_time)/60) + " minutes")
            start_time = time.time()

        logger.info('Epoch: %03d / %03d' % (epoch, args.epochs))
        meter_train.step_setting(epoch)
        train_epoch(train_loader, model, optimizer, scheduler,  # Basic
                    loss_functions, metric_functions, meter_train, logger, best_perf,  # Performance
                    epoch, results_dict, path,scaler, args)  # ETC
        if args.UseTB_train:
            meter_train.write_scalars_TB()
        meter_train.reset()

        if epoch % args.validation_frequency == 0:
            meter_val.step_setting(epoch)
            validate_epoch(val_loader, model, optimizer, scheduler,  # Basic
                           loss_functions, metric_functions, meter_val, logger, best_perf,  # Performance
                           epoch, results_dict, path, scaler, args)  # ETC
            meter_val.write_scalars_TB()
            meter_val.reset()

        logger.info('')

    print("Training Finished")


if __name__ == '__main__':
    main()
