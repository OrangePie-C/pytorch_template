'''
Copyright (c) 2017 Hai Pham, Rutgers University
http://www.cs.rutgers.edu/~hxp1/

This code is free to use for academic/research purpose.

'''
import math
import pathlib as plb
import librosa
import csv
import numpy as np
import wave
import contextlib
from .extract_feature import write_csv, get_fps, extract_one_frame_data
import os
FREQ_DIM = 128
TIME_DIM = 32
NFFT = FREQ_DIM*2

nFrameSize = (TIME_DIM - 3) * FREQ_DIM + NFFT

def extract_one_file(audiofile):
    #print (" --- " + audiofile)
    # get video FPS
    with contextlib.closing(wave.open(audiofile, 'r')) as f:
        frames = f.getnframes()
        rate = f.getframerate()
        #print()
        #print(frames)
        #print(rate)
        duration = frames / float(rate)
        #print(duration)
    # 29.7 -1
    # 29.75 0
    # 29.8 0
    # 29.85 0
    # 29.9 0
    # 29.95 0
    # 30.0 1
    fps = 29.98
    nFrames = int(fps*duration)

    # load audio
    data, sr = librosa.load(audiofile, sr=44100) # data is np.float32
    # number of audio samples per video frame
    nSamPerFrame = int(math.floor(float(sr) / fps))
    # number of samples per 20ms
    #nSamPerFFTWindow = NFFT #int(math.ceil(float(sr) * 0.02))
    # number of samples per step 8ms
    #nSamPerStep = FREQ_DIM #int(math.floor(float(sr) * 0.008))
    # number of steps per frame
    #nStepsPerFrame = TIME_DIM #int(math.floor(float(nSamPerFrame) / float(nSamPerStep)))
    # real frame size
    #nFrameSize = (nStepsPerFrame - 1) * nSamPerStep + nSamPerFFTWindow
    # initial position in the sound stream
    # initPos negative means we need zero padding at the front.
    curPos = nSamPerFrame - nFrameSize
    dbspecs = []
    for f in range(0,nFrames):
        frameData, nextPos = extract_one_frame_data(data, curPos, nFrameSize, nSamPerFrame)
        curPos = nextPos
        # spectrogram transform
        FD = librosa.core.stft(y=frameData, n_fft=NFFT, hop_length=FREQ_DIM)
        FD, phase = librosa.magphase(FD)
        DB = librosa.core.amplitude_to_db(FD, ref=np.max)
        # scale dB-spectrogram in [0,1]
        DB = np.divide(np.absolute(DB), 80.0)
        # remove the last row
        newDB = DB[0:-1,:]
        # store
        dbspecs.append(newDB.flatten().tolist())
    return dbspecs

video_root = r"C:\Users\Jeff\PycharmProjects\end2end_AU_speech-master\Video_Speech_Actor_21"
#audio_root = r"C:\Users\Jeff\PycharmProjects\end2end_AU_speech-master\wav_source"
feat_root = r"C:\Users\Jeff\PycharmProjects\end2end_AU_speech-master\feat_single"

def process_all(audio_root):
    soundfile_list = os.listdir(audio_root)
    #feat_dir = plb.Path(feat_root)
    #feat_dir.mkdir(parents=True, exist_ok=True)
    if os.path.isdir('./spectrum_files/') == False:
        os.mkdir('./spectrum_files/')
    os.mkdir('./Custom_Soundfiles/temp_frames/')
    os.mkdir('./Custom_Soundfiles/temp_videos/')
    # print(type(audio_stem))
    # print(audio_stem)
    # audio_stem[1] = '3'

    for i in soundfile_list:
        feature_path = './spectrum_files/' + i[:-4] + ".csv"
        if os.path.isfile(feature_path) == False:
            audio_path = audio_root + '/' + i
            dbspecs = extract_one_file(audio_path)

            write_csv(feature_path, dbspecs)
    return soundfile_list

if __name__ == "__main__":
    filenames = ['Eng_angry','Eng_neutral','Eng_neutral_long','Eng_sad','Kor_angry','Kor_happy','Kor_neutral','Kor_sad']
    for i in filenames:
        process_all(i)