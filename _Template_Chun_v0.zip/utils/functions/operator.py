
import torch
from abc import abstractmethod
from numpy import inf
from utils.commons import TensorboardWriter
from utils.commons import progress_bar
from tqdm import tqdm
import time

def _resume_checkpoint(self, resume_path):
    """
    Resume from saved checkpoints

    :param resume_path: Checkpoint path to be resumed
    """
    resume_path = str(resume_path)
    self.logger.info("Loading checkpoint: {} ...".format(resume_path))
    checkpoint = torch.load(resume_path)
    self.start_epoch = checkpoint['epoch'] + 1
    self.mnt_best = checkpoint['monitor_best']

    # load architecture params from checkpoint.
    if checkpoint['config']['arch'] != self.config['arch']:
        self.logger.warning("Warning: Architecture configuration given in config file is different from that of "
                            "checkpoint. This may yield an exception while state_dict is being loaded.")
    self.model.load_state_dict(checkpoint['state_dict'])

    # load optimizer state from checkpoint only when optimizer type is not changed.
    if checkpoint['config']['optimizer']['type'] != self.config['optimizer']['type']:
        self.logger.warning("Warning: Optimizer type given in config file is different from that of checkpoint. "
                            "Optimizer parameters not being resumed.")
    else:
        self.optimizer.load_state_dict(checkpoint['optimizer'])

    self.logger.info("Checkpoint loaded. Resume training from epoch {}".format(self.start_epoch))

def save_checkpoint(model, optimizer, epoch, logger, model_path, cur_perf, best_perf, args):
    """
    Saving checkpoints

    :param epoch: current epoch number
    :param log: logging information of the epoch
    :param save_best: if True, rename the saved checkpoint to 'model_best.pth'
    """

    state = {
        'epoch': epoch,
        'state_dict': model.state_dict(),
        'optimizer': optimizer.state_dict(),
        'monitor_best': best_perf.return_value(),
        'args': args
    }
    filename = str(model_path + '/checkpoint-epoch{}.pth'.format(epoch))
    torch.save(state, filename)
    #logger.info("Saving checkpoint: {} ...".format(filename))
    filename = str(model_path + '/model_last.pth')
    torch.save(state, filename)


    # Save best
    if cur_perf >= best_perf.return_value():
        best_perf.update(cur_perf)
        best_path = str(model_path + '/model_best.pth')
        torch.save(state, best_path)
        logger.info("Best Performance Found! : {}".format(best_perf.return_value()))

######################################################################################
def train_epoch(train_loader, model,  optimizer, scheduler, # Basic
                    loss_functions, metric_functions, meter, logger, best_perf,  # Performance
                    device, epoch, results_dict, model_path, args):  # ETC
    model.train()
    #for param_group in optimizer.param_groups:
    #    print(param_group['lr'])
    scheduler.step(epoch)
    #for param_group in optimizer.param_groups:
    #    print(param_group['lr'])
    for batch_idx, (data, target) in enumerate(train_loader):

        data, target = data.to(device), target.to(device)  # B x H x W
        num_samples = data.shape[0]

        start = time.time()
        output = model(data)
        end = time.time()

        optimizer.zero_grad()
        for l_func in loss_functions:
            loss = l_func()(output, target)
            loss.backward()
            meter.update(l_func.__name__, loss.item(), n = num_samples)
        optimizer.step()

        # Record Meters

        # Record Metrics
        for m_func in metric_functions:
             meter.update(m_func.__name__, m_func(output, target), n = num_samples)

        # Record ETC
        meter.update('time of each sample', end - start, n = num_samples)


        progress_bar(batch_idx, len(train_loader), args.epochs, epoch,
                     (str(args.metrics['critical_metric'] + ' : ' + str(meter.result()[
                         args.metrics['critical_metric']]))))
        # meter...
    #cur_perf = meter.result()[args.metrics['critical_metric'] + ' (train)']  # standard metric
    #scheduler.step(epoch)
    meter.step_setting(epoch)
    #meter.write_scalars_TB()

    #save_checkpoint(model, optimizer, epoch, logger, model_path, cur_perf, best_perf, args)



def validate_epoch(val_loader, model, optimizer, scheduler,  # Basic
                    loss_functions, metric_functions, meter, logger, best_perf,  # Performance
                    device, epoch, results_dict, model_path, args):  # ETC
    model.eval()

    with torch.no_grad():
        for batch_idx, (data, target) in enumerate(val_loader):

            data, target = data.to(device), target.to(device)  # B x H x W
            num_samples = data.shape[0]

            start = time.time()
            output = model(data)
            end = time.time()

            # Record Meters

            for l_func in loss_functions:
                loss = l_func()(output, target)
                meter.update(l_func.__name__, loss.item(), n=num_samples)

            # Record Metrics
            for m_func in metric_functions:
                meter.update(m_func.__name__, m_func(output, target), n=num_samples)

            # Record ETC
            meter.update('time of each sample', end - start, n=num_samples)

            progress_bar(batch_idx, len(val_loader), args.epochs, epoch,
                         (str(args.metrics['critical_metric'] + ' : ' + str(meter.result()[
                                                                                args.metrics[
                                                                                    'critical_metric']]))))

        cur_perf = meter.result()[args.metrics['critical_metric']]  # standard metric
        save_checkpoint(model, optimizer, epoch, logger, model_path, cur_perf, best_perf, args)

