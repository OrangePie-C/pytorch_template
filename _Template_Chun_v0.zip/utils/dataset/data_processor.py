from torchvision import datasets, transforms
from torch.utils.data import Dataset




def load_dataset(args,train=True):

    # Set Transformations (variable)
    transform_train = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])

    # Load dataset (variable)
    if args.data['dataset'] == 'MNIST':
        trainset = datasets.MNIST(root=args.directory['data_dir'], train=train, download=True, transform=transform_train)
    else:
        raise ValueError(args.data['dataset'])

    return trainset
