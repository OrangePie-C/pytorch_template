from torchvision import datasets, transforms
from base import BaseDataLoader
from torch.utils.data import Dataset


class BaseDataset(Dataset):
    def __init__(self):
        pass

    def __getitem__(self, index): # Important Step
        pass
        # """
        # Args:
        #     index (int): Index
        #
        # Returns:
        #     tuple: (image, target) where target is index of the target class.
        # """
        # img, target = self.data[index], int(self.targets[index])
        #
        # # doing this so that it is consistent with all other datasets
        # # to return a PIL Image
        # img = Image.fromarray(img.numpy(), mode='L')
        #
        # if self.transform is not None:
        #     img = self.transform(img)
        #
        # if self.target_transform is not None:
        #     target = self.target_transform(target)

        # return img, target





def load_dataset(args,train=True):

    # Set Transformations (variable)
    transform_train = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),

    ])

    # Load dataset (variable)
    if args.data['dataset'] == 'MNIST':
        trainset = datasets.MNIST(root=args.directory['data_dir'], train=train, download=True, transform=transform_train)
    else:
        raise ValueError(args.data['dataset'])


    return trainset
