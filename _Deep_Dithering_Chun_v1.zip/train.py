
import torch
from torch.utils.data import DataLoader

# custom
from utils.commons import configurator  # , configuration
from utils.dataset.data_processor import load_dataset
from model.networks import Model_Establishment

from utils.trainer import metric
from utils.trainer import criterion
from utils.trainer.criterion import criterion_establishment  # loss related
from utils.trainer.metric import MetricTracker
from utils.trainer.optimizer import Optimizer_Establishment  # optimizer related
from utils.trainer.scheduler import Scheduler_Establishment

from utils.commons.util import Initialization, Finalization
from utils.functions.operator import train_epoch, validate_epoch
from itertools import chain

import sys
import warnings

# turn off printing option?
# validation frequency
if not sys.warnoptions:
    warnings.simplefilter("ignore")

def main():
    # save model + resume?

    # Initialization : Configuration, Logger,
    args = configurator.Load_Config().parse_args()
    logger, TBwriter, path = Initialization(args)

    # result variable
    results_dict = {
        '1_loss_list': args.metrics['1_loss_list'],  # regarding
        '2_metric_list': args.metrics['2_metric_list'],
        '3_etc_list': args.metrics['3_etc_list']
                    }
    result_list = list(chain.from_iterable(list(results_dict.values())))

    # Dataloader
    train_dataset = load_dataset(args, train=True)
    val_dataset = load_dataset(args, train=False)

    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch, shuffle=True,
                                               num_workers=args.workers, pin_memory=True)
    val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=args.batch, shuffle=False,
                                             num_workers=args.workers, pin_memory=True)
    data_shape = (train_dataset.data.shape[3],train_dataset.data.shape[1],train_dataset.data.shape[2])
    #print(train_dataset.data.shape)

    # Model
    model = Model_Establishment(args)

    # Trainer Option
    loss_functions = [getattr(criterion, loss) for loss in results_dict['1_loss_list']]
    metric_functions = [getattr(metric, met) for met in results_dict['2_metric_list']]
    optimizer = Optimizer_Establishment(model, args)
    scheduler = Scheduler_Establishment(optimizer, args)
    meter_train = MetricTracker(result_list, results_dict, writer=TBwriter['train'])
    meter_val = MetricTracker(result_list, results_dict, writer=TBwriter['val'])

    # Finalization
    model, optimizer, starting_epoch, best_perf, args = Finalization(model, optimizer, path, logger, args, data_shape)

    # Write Network
    meter_train.write_network(model, args, data_shape)
    meter_val.write_network(model, args, data_shape)

    logger.info("Start Training...\n")

    for epoch in range(starting_epoch, args.epochs + 1):

        logger.info('Epoch: %03d / %03d' % (epoch, args.epochs))
        meter_train.step_setting(epoch)
        train_epoch(train_loader, model, optimizer, scheduler,  # Basic
                    loss_functions, metric_functions, meter_train, logger, best_perf,  # Performance
                    epoch, results_dict, path, args)  # ETC
        meter_train.write_scalars_TB()
        meter_train.reset()

        if epoch % args.validation_frequency == 0:
            meter_val.step_setting(epoch)
            validate_epoch(val_loader, model, optimizer, scheduler,  # Basic
                           loss_functions, metric_functions, meter_val, logger, best_perf,  # Performance
                           epoch, results_dict, path, args)  # ETC
            meter_val.write_scalars_TB()
            meter_val.reset()

        logger.info('')

    print("Training Finished")

    # trainloader는 데이터
    # model은 네트워크
    # criterion_dict loss 계산 함수
    # optimizer는 최적화
    # scheduler는 말할 필요도 없징
    # metric meter 는 기록기 (각 epoch 마다 reset)

    # save model??

    # validate_epoch()


if __name__ == '__main__':
    main()
