import numpy as np
from PIL import Image
import cv2
import torch
def get_new_val(old_val, nc):
    """
    Get the "closest" colour to old_val in the range [0,1] per channel divided
    into nc values.

    """

    return np.round(old_val * (nc - 1)) / (nc - 1)
# def palette_reduce(img, nc):
#     """Simple palette reduction without dithering."""
#     arr = np.array(img, dtype=float) / 255
#     arr = get_new_val(arr, nc)
#     #carr = np.array(arr/np.max(arr) * 255, dtype=np.uint8)
#     carr = np.array(arr / 1.0 * 255, dtype=np.uint8)
#     #return Image.fromarray(carr)
#     return carr
def palette_reduce(img, nc):
    """Simple palette reduction without dithering."""
    # arr = np.array(img, dtype=float) / 255
    arr = np.array(img, dtype=float) # / 255
    arr = get_new_val(arr, nc)
    #carr = np.array(arr/np.max(arr) * 255, dtype=np.uint8)
    carr = np.array(arr / 1.0, dtype=np.float)
    #return Image.fromarray(carr)
    return carr
def tensor2np(img):
    a = img.cpu().detach().numpy().transpose(1,2,0)
    a = (a*255).round().astype(np.uint8)
    r,g,b = cv2.split(a)
    a[:,:,0], a[:,:,1], a[:,:,2] = b,g,r
    return a

def np2tensor(img):
    b, g, r = cv2.split(img)
    img[:, :, 0], img[:, :, 1], img[:, :, 2] = r, g, b
    img = img / 255
    img = img.transpose(2,0,1)
    img = torch.tensor(img).cuda()

    return img