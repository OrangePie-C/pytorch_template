from torchvision import datasets, transforms
from torch.utils.data import Dataset




def load_dataset(args,train=True):

    # Set Transformations (variable)
    transform_train = transforms.Compose([
        #transforms.RandomCrop(32, padding=4),
        #transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        #transforms.Normalize((0.5071, 0.4867, 0.4408), (0.2675, 0.2565, 0.2761)),
    ])

    # Load dataset (variable)
    if args.data['dataset'] == 'MNIST':
        trainset = datasets.MNIST(root=args.directory['data_dir'], train=train, download=True, transform=transform_train)
    elif args.data['dataset'] == 'CIFAR100':
        trainset = datasets.CIFAR100(root=args.directory['data_dir'], train=train, download=True,
                                  transform=transform_train)
    else:
        raise ValueError(args.data['dataset'])

    return trainset
