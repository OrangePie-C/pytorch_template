import json
import math
import os
from pathlib import Path
from tempfile import NamedTemporaryFile
from deepspeech_pytorch.enums import SpectrogramWindow
import librosa
import numpy as np
import sox
import torch
from torch.utils.data import Dataset, Sampler, DistributedSampler, DataLoader
import torchaudio
from deepspeech_pytorch.loader.spec_augment import spec_augment
from deepspeech_pytorch.enums import DecoderType
#torchaudio.set_audio_backend("sox_io")

def augment_audio_with_sox(path, sample_rate, tempo, gain):
    """
    Changes tempo and gain of the recording with sox and loads it.
    """
    with NamedTemporaryFile(suffix=".wav") as augmented_file:
        augmented_filename = augmented_file.name
        sox_augment_params = ["tempo", "{:.3f}".format(tempo), "gain", "{:.3f}".format(gain)]
        sox_params = "sox \"{}\" -r {} -c 1 -b 16 -e si {} {} >/dev/null 2>&1".format(path, sample_rate,
                                                                                      augmented_filename,
                                                                                      " ".join(sox_augment_params))
        os.system(sox_params)
        y = load_audio(augmented_filename)
        return y

def load_audio(path):
    sound, sample_rate = torchaudio.load(path)
    if sound.shape[0] == 1:
        sound = sound.squeeze()
    else:
        sound = sound.mean(axis=0)  # multiple channels, average
    return sound.numpy()

def load_randomly_augmented_audio(path, sample_rate=16000, tempo_range=(0.85, 1.15),
                                  gain_range=(-6, 8)):
    """
    Picks tempo and gain uniformly, applies it to the utterance by using sox utility.
    Returns the augmented utterance.
    """
    low_tempo, high_tempo = tempo_range
    tempo_value = np.random.uniform(low=low_tempo, high=high_tempo)
    low_gain, high_gain = gain_range
    gain_value = np.random.uniform(low=low_gain, high=high_gain)
    audio = augment_audio_with_sox(path=path, sample_rate=sample_rate,
                                   tempo=tempo_value, gain=gain_value)
    return audio

def parse_audio(audio_path):
    print("hit1")
    # if self.aug_conf and self.aug_conf.speed_volume_perturb:
    #     y = load_randomly_augmented_audio(audio_path, self.sample_rate)
    # else:
    #     y = load_audio(audio_path)
    y = load_audio(audio_path)
    # if self.noise_injector:
    #     add_noise = np.random.binomial(1, self.aug_conf.noise_prob)
    #     if add_noise:
    #         y = self.noise_injector.inject_noise(y)
    sample_rate = 16000
    window_size = 0.02 # sec
    window_stride = 0.01
    window = SpectrogramWindow.hamming.value

    normalize = True

    n_fft = int(sample_rate * window_size)
    win_length = n_fft
    hop_length = int(sample_rate * window_stride)
    # STFT
    D = librosa.stft(y, n_fft=n_fft, hop_length=hop_length,
                     win_length=win_length, window=window)
    spect, phase = librosa.magphase(D)
    # S = log(S+1)
    spect = np.log1p(spect)
    spect = torch.FloatTensor(spect)
    if normalize:
        mean = spect.mean()
        std = spect.std()
        spect.add_(-mean)
        spect.div_(std)

    # if self.aug_conf and self.aug_conf.spec_augment:
    #     spect = spec_augment(spect)
    print("hit2")
    return spect

def parse_transcript(self, transcript_path):
    with open(transcript_path, 'r', encoding='utf8') as transcript_file:
        transcript = transcript_file.read().replace('\n', '')
    transcript = list(filter(None, [self.labels_map.get(x) for x in list(transcript)]))
    return transcript

class LMConfig:
    decoder_type: DecoderType = DecoderType.greedy
    lm_path: str = ''  # Path to an (optional) kenlm language model for use with beam search (req\'d with trie)
    top_paths: int = 1  # Number of beams to return
    alpha: float = 0.0  # Language model weight
    beta: float = 0.0  # Language model word bonus (all words)
    cutoff_top_n: int = 40  # Cutoff_top_n characters with highest probs in vocabulary will be used in beam search
    cutoff_prob: float = 1.0  # Cutoff probability in pruning,default 1.0, no pruning.
    beam_width: int = 10  # Beam width to use
    lm_workers: int = 4  # Number of LM processes to use