
int read_bits(FILE *f, INT32 *bits, int len);
void write_bits(FILE *f, INT32 *bits, int len);
