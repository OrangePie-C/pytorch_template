

#from .deepspeech_pytorch.model import DeepSpeech/
from deepspeech_pytorch.model import DeepSpeech
from deepspeech_pytorch.loader.data_loader import SpectrogramDataset, AudioDataLoader
from utils import *
from deepspeech_pytorch.utils import load_model, load_decoder
model_path = './librispeech_pretrained_v3.ckpt'
audio_dir = r'C:/Users/Jeff/PycharmProjects/_VOCA_Chun_v0/data/test_sentence.wav'
#model = DeepSpeech.load_from_checkpoint(hydra.utils.to_absolute_path(model_path))



net = torch.load(model_path)


model = DeepSpeech.load_from_checkpoint(model_path)


spect = parse_audio(audio_dir)
#transcript = parse_transcript(transcript_path)

spect = spect.reshape([1,1,161,701])




def getiton(spect):
    def func(p):
        return p[0].size(1)

    batch = sorted(spect, key=lambda sample: sample[0].size(1), reverse=True)
    longest_sample = max(batch, key=func)[0]
    freq_size = longest_sample.size(0)
    minibatch_size = len(batch)
    max_seqlength = longest_sample.size(1)
    inputs = torch.zeros(1, 1, freq_size, max_seqlength)
    input_percentages = torch.FloatTensor(minibatch_size)
    for x in range(minibatch_size):
        sample = batch[x]
        tensor = sample[0]
        seq_length = tensor.size(1)
        inputs[x][0].narrow(1, 0, seq_length).copy_(tensor)
        input_percentages[x] = seq_length / float(max_seqlength)


    return inputs, input_percentages

spect, input_percentages = getiton(spect)






model.eval()
#model = model.to(device)



input_sizes = input_percentages.mul_(int(spect.size(3))).int()



#with autocast(enabled=precision == 16):
out, output_sizes = model(spect, input_sizes)
#  three indices reserved for space, apostrophe and the CTC blank label (although we currently strip apostrophes from the source texts)
print(out)
#print(out.argmax(dim=2))
print(out.shape)
print(out.flatten().shape)
print(output_sizes)


decoder = load_decoder(
        labels=model.labels,
        cfg=LMConfig()
    )
decoded_output, sub = decoder.decode(out, output_sizes)

print(decoded_output)

print(sub)
# 351 : 61

exit()

