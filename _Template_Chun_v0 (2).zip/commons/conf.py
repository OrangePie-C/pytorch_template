dataroot = '/data/private/pretrainedmodels'
imagenet_path = '/data/public/rw/datasets/imagenet-pytorch'
sodeep_model = '/data/private/repos/sodeep/weights/best_model_gruc.pth.tar'