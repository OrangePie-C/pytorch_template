
import torch.optim as optim







def Optimizer_Establishment(model, args):
    #model = globals()[model_name.capitalize()]()
    optimizer = optim.SGD(model.parameters(), args.lr)

    return optimizer